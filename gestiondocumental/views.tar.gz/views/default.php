<? include("cabecera.php"); ?>
<? include("menu.php"); ?>

<form name="frmmenu" action="" method="post">
<table align="center" width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
    	<td height="250">

        </td>
    </tr>
</table>
</form>
<? include("pie.php"); ?>