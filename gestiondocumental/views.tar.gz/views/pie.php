<br /><br />
<div class="clear"></div>
		<div id="pie">
			&copy;<?php echo date("Y")?> | <?php echo $nom_sistema ?> | <?=$_SESSION["nombre_empresa"]?>
		</div>
	</body>
</html>
